<script>
	let { children } = $props();
</script>


<h1> My Header</h1>
{@render children()}